﻿/*---------- 
 * 
 * html js textarea 修改 .txt
 * 
 * ----------*/

 
 
function download(){
    var text = document.getElementById("SeeTest").value;
    text = text.replace(/\n/g, "\r\n"); // To retain the Line breaks.
    var blob = new Blob([text], { type: "text/plain"});
    var anchor = document.createElement("a");
    anchor.download = " ";
    anchor.href = window.URL.createObjectURL(blob);
    anchor.target ="_blank";
    anchor.style.display = "none"; // just to be safe!
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
 }
















/*---------- 
 * 
 * html js textarea 讀取 .txt
 * https://stackoverflow.com/questions/35188924/reading-txt-file-into-a-textarea-using-javascript
 * 
 * ----------*/














/*---------- 
 * 
 * jquery change iframe1 href on input
 * 
 * 
 * ----------*/





   
   function changeSTAGEsrc()
{
  

document.getElementById("STAGE").src = document.getElementById("ChgSTAGEBtn").value;
   
}



   function changeIimsrc()
{

document.getElementById("Iim").src = document.getElementById("ChgIimBtn").value;

   
}


   function changePagesrc()
{

document.getElementById("Page").src = document.getElementById("ChgPageBtn").value;

   
}
   function changeprofilesrc()
{
  

document.getElementById("profile").src = document.getElementById("ChgprofileBtn").value;

   
}
   function changeBatsrc()
{
  
document.getElementById("Bat").src = document.getElementById("ChgBatBtn").value;

   
}
/*---------- 
 * 
 * jquery change iframe1 href on input
 * 
 * END
 * ----------*/
 
 
 
 
 
 
 
 
 
 
